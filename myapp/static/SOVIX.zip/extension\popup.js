// Portal list: built-in (portals.js + .env) + custom (chrome.storage.local).
// Koi backend nahi.

const AVATAR_COLORS = ["#f5a623", "#4a90d9", "#555555", "#7ed321", "#1a3a6b", "#8e44ad", "#16a085"];
function avatarColor(name) {
  let h = 0;
  for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

async function getCustomPortals() {
  try {
    const data = await chrome.storage.local.get("customPortals");
    return Array.isArray(data.customPortals) ? data.customPortals : [];
  } catch { return []; }
}

async function getAllPortals() {
  const customs = await getCustomPortals();
  return [...Object.values(PORTALS), ...customs];
}

// Edit mode: null = naya portal, id = existing update ho raha hai
let editingId = null;

const KIND_LABELS = { "fill-user": "Input: Username", "fill-pass": "Input: Password", "fill-mfa": "Input: MFA Code", "click": "Click: Button", "wait": "Wait" };

// ── TOTP (RFC 6238, SHA1, 30s, 6-digit) — form me live code preview ke liye ──
function totpBase32Decode(s) {
  const alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const clean = String(s || "").toUpperCase().replace(/[^A-Z2-7]/g, "");
  let bits = 0, val = 0;
  const out = [];
  for (const ch of clean) {
    val = (val << 5) | alpha.indexOf(ch);
    bits += 5;
    if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
  }
  return out;
}
function totpSha1(bytes) {
  let h0 = 0x67452301, h1 = 0xEFCDAB89, h2 = 0x98BADCFE, h3 = 0x10325476, h4 = 0xC3D2E1F0;
  const msg = bytes.slice();
  const bitLen = msg.length * 8;
  msg.push(0x80);
  while (msg.length % 64 !== 56) msg.push(0);
  const hi = Math.floor(bitLen / 0x100000000), lo = bitLen >>> 0;
  msg.push((hi >>> 24) & 255, (hi >>> 16) & 255, (hi >>> 8) & 255, hi & 255,
           (lo >>> 24) & 255, (lo >>> 16) & 255, (lo >>> 8) & 255, lo & 255);
  const w = new Array(80);
  const rol = (n, s) => ((n << s) | (n >>> (32 - s))) >>> 0;
  for (let i = 0; i < msg.length; i += 64) {
    for (let t = 0; t < 16; t++) w[t] = ((msg[i + t * 4] << 24) | (msg[i + t * 4 + 1] << 16) | (msg[i + t * 4 + 2] << 8) | msg[i + t * 4 + 3]) >>> 0;
    for (let t = 16; t < 80; t++) w[t] = rol(w[t - 3] ^ w[t - 8] ^ w[t - 14] ^ w[t - 16], 1);
    let a = h0, b = h1, c = h2, d = h3, e = h4;
    for (let t = 0; t < 80; t++) {
      let f, k;
      if (t < 20) { f = (b & c) | ((~b) & d); k = 0x5A827999; }
      else if (t < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
      else if (t < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
      else { f = b ^ c ^ d; k = 0xCA62C1D6; }
      const tmp = (rol(a, 5) + f + e + k + w[t]) >>> 0;
      e = d; d = c; c = rol(b, 30); b = a; a = tmp;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0; h4 = (h4 + e) >>> 0;
  }
  const out = [];
  for (const h of [h0, h1, h2, h3, h4]) out.push((h >>> 24) & 255, (h >>> 16) & 255, (h >>> 8) & 255, h & 255);
  return out;
}
function totpHmacSha1(key, msg) {
  let k = key.slice();
  if (k.length > 64) k = totpSha1(k);
  while (k.length < 64) k.push(0);
  const ipad = k.map((b) => b ^ 0x36), opad = k.map((b) => b ^ 0x5c);
  return totpSha1(opad.concat(totpSha1(ipad.concat(msg))));
}
function totpGenerate(secret, nowMs) {
  const key = totpBase32Decode(secret);
  if (!key.length) return "";
  const counter = Math.floor((nowMs || Date.now()) / 30000);
  const msg = [0, 0, 0, 0, (counter >>> 24) & 255, (counter >>> 16) & 255, (counter >>> 8) & 255, counter & 255];
  const h = totpHmacSha1(key, msg);
  const off = h[h.length - 1] & 15;
  const code = ((h[off] & 127) << 24) | (h[off + 1] << 16) | (h[off + 2] << 8) | h[off + 3];
  return String(code % 1000000).padStart(6, "0");
}
function totpSecretOk(s) {
  return String(s || "").toUpperCase().replace(/[^A-Z2-7]/g, "").length >= 8;
}
function mfaPreviewText(secret) {
  if (!String(secret || "").trim()) return "Secret likho — yahi live code dikhega";
  if (!totpSecretOk(secret)) return "Secret sahi nahi hai (Base32: A-Z, 2-7)";
  const code = totpGenerate(secret, Date.now());
  const left = 30 - (Math.floor(Date.now() / 1000) % 30);
  return code ? ("Abhi ka code: " + code + " (" + left + "s)") : "Secret sahi nahi hai";
}
// Har second MFA preview refresh karo (code har 30s badalta hai)
setInterval(() => {
  document.querySelectorAll("#stepsList .step-row").forEach((row) => {
    const sel = row.querySelector(".step-bottom select");
    const pv = row.querySelector(".mfa-preview");
    if (!sel || !pv) return;
    if (sel.value !== "fill-mfa") { pv.style.display = "none"; return; }
    pv.style.display = "";
    const param = row.querySelector(".step-bottom input");
    pv.textContent = mfaPreviewText(param ? param.value : "");
  });
}, 1000);

// View: portal details read-only modal me dikhao
function viewPortal(p) {
  document.getElementById("viewTitle").textContent = p.name || p.id;
  const body = document.getElementById("viewBody");
  body.innerHTML = "";
  function addRow(label, value) {
    const d = document.createElement("div");
    d.className = "vrow";
    const b = document.createElement("b");
    b.textContent = label + ": ";
    d.appendChild(b);
    d.appendChild(document.createTextNode(value || "-"));
    body.appendChild(d);
  }
  addRow("URL", p.loginUrl || p.homeUrl);
  const steps = Array.isArray(p.steps) ? p.steps : [];
  addRow("Flow steps", steps.length ? String(steps.length) : (p.custom ? "auto (default)" : "built-in (.env + auto)"));
  steps.forEach((s, i) => {
    const box = document.createElement("div");
    box.className = "vstep";
    const k = document.createElement("div");
    k.className = "vk";
    k.textContent = (i + 1) + ". " + (KIND_LABELS[s.kind] || s.kind);
    box.appendChild(k);
    if (s.name) {
      const n = document.createElement("div");
      n.className = "vn";
      n.textContent = s.name;
      box.appendChild(n);
    }
    if (s.selector) {
      const sl = document.createElement("div");
      sl.className = "vs";
      sl.textContent = s.selector;
      box.appendChild(sl);
    }
    if (s.kind === "wait") {
      const m = document.createElement("div");
      m.className = "vv";
      m.textContent = (s.ms || 2000) + " ms";
      box.appendChild(m);
    } else if (s.value) {
      const v = document.createElement("div");
      v.className = "vv";
      if (s.kind === "fill-mfa") v.textContent = "MFA secret: •••• (code auto-generate, har 30s)";
      else v.textContent = "value: " + (s.kind === "fill-pass" ? "••••••••" : s.value);
      box.appendChild(v);
    }
    body.appendChild(box);
  });
  document.getElementById("viewModal").classList.remove("hidden");
}

// Edit: form ko portal data se bharo
function editPortal(p) {
  resetAddForm();
  document.getElementById("fName").value = p.name || "";
  document.getElementById("fUrl").value = p.loginUrl || p.homeUrl || "";
  const box = document.getElementById("stepsList");
  box.innerHTML = "";
  (p.steps || []).forEach((s) => {
    addStepRow(s.kind || "fill-user", s.name || "", s.selector || "",
      s.kind === "wait" ? String(s.ms || 2000) : (s.value || ""));
  });
  if (!(p.steps || []).length) {
    box.innerHTML = '<div class="step-empty">+ Add step dabakar flow banao (e.g. Username, Password, Login button).</div>';
  }
  editingId = p.id;
  document.getElementById("savePortalBtn").textContent = "Update Portal";
  document.getElementById("status").textContent = "";
  showView("add");
}

document.getElementById("viewClose").onclick = () => {
  document.getElementById("viewModal").classList.add("hidden");
};
document.getElementById("viewModal").onclick = (e) => {
  if (e.target.id === "viewModal") e.target.classList.add("hidden");
};

// Side panel me window.close() panel band kar deta hai, isliye auto-close poori tarah hata diya.
// Popup sirf tab band hoga jab user khud bahar click kare / Esc dabaye.
const IS_SIDE = window.IS_SIDEPANEL === true;

async function renderList() {
  const list = document.getElementById("list");
  const status = document.getElementById("status");
  list.innerHTML = "";
  const items = await getAllPortals();
  if (!items.length) {
    list.innerHTML = '<div class="empty">Koi portal nahi mila. + dabakar add karo.</div>';
  } else {
    status.textContent = "";
  }
  for (const p of items) {
    const row = document.createElement("div");
    row.className = "portal";

    const av = document.createElement("div");
    av.className = "avatar";
    av.style.background = avatarColor(p.name || p.id);
    av.textContent = (p.name || p.id || "?").trim().charAt(0).toUpperCase();

    const info = document.createElement("div");
    info.className = "pinfo";
    const nm = document.createElement("div");
    nm.className = "pname";
    nm.textContent = p.name || p.id;
    info.appendChild(nm);

    const btn = document.createElement("button");
    btn.className = "open-btn";
    btn.title = "Open " + (p.name || p.id);
    btn.textContent = "\u2192";

    const open = async () => {
      btn.disabled = true;
      status.textContent = `${p.name} khul raha, fields bhare ja rahe (10-20 sec)...`;
      try {
        // Popup se kholo to tab background me (popup khula rahe), side se kholo to saamne
        const resp = await chrome.runtime.sendMessage({ type: "AUTOLOGIN", portalId: p.id, openInBackground: !IS_SIDE });
        if (resp?.mode === "fill") {
          let msg = `${p.name} me login details bhar diye.`;
          if (resp.flowSteps) msg += ` (flow: ${resp.flowSteps} steps OK)`;
          else if (resp.submitted?.clicked) msg += " Login button dabaa diya.";
          else msg += " (Login khud dabao)";
          if (resp.selectorsSaved) msg += " (fields save, agli baar fast)";
          if (!IS_SIDE) msg += " Tab par click karke dekho.";
          status.textContent = msg;
          return;
        }
        if (resp?.warning) {
          status.textContent = `Tab khula. Fill nahi hua: ${resp.warning}`;
        } else if (resp?.ok === false) {
          status.textContent = "Error: " + (resp?.error || "fail");
        } else {
          status.textContent = `${p.name} new tab me khul gaya.` + (!IS_SIDE ? " Tab par click karke dekho." : "");
          return;
        }
      } catch (e) {
        status.textContent = "Error: " + e.message + " (extension Reload karke dekho)";
      }
      btn.disabled = false;
    };
    btn.onclick = open;
    row.onclick = (e) => {
      if (e.target.closest && e.target.closest(".mini-act")) return;
      if (e.target !== btn && !btn.disabled) open();
    };

    row.appendChild(av);
    row.appendChild(info);

    // Custom portal par View / Edit / Delete actions
    if (p.custom) {
      const actions = document.createElement("div");
      actions.className = "row-actions";
      const eyeSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
      const penSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/></svg>';
      const trashSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>';
      const view = document.createElement("button");
      view.className = "mini-act"; view.title = "View portal"; view.innerHTML = eyeSvg;
      view.onclick = (e) => { e.stopPropagation(); viewPortal(p); };
      const edit = document.createElement("button");
      edit.className = "mini-act"; edit.title = "Edit portal"; edit.innerHTML = penSvg;
      edit.onclick = (e) => { e.stopPropagation(); editPortal(p); };
      const del = document.createElement("button");
      del.className = "mini-act danger"; del.title = "Delete portal"; del.innerHTML = trashSvg;
      del.onclick = async (e) => {
        e.stopPropagation();
        const arr = await getCustomPortals();
        await chrome.storage.local.set({ customPortals: arr.filter((x) => x.id !== p.id) });
        status.textContent = `"${p.name}" delete ho gaya.`;
        renderList();
      };
      actions.appendChild(view); actions.appendChild(edit); actions.appendChild(del);
      row.appendChild(actions);
    }

    row.appendChild(btn);
    list.appendChild(row);
  }
  const count = document.getElementById("portalCount");
  if (count) count.textContent = items.length + (items.length === 1 ? " portal" : " portals");
}

// Views: list vs add form
function showView(which) {
  document.getElementById("listView").classList.toggle("hidden", which !== "list");
  document.getElementById("addView").classList.toggle("hidden", which !== "add");
  document.querySelector(".search").classList.toggle("hidden", which !== "list");
  document.querySelector(".section").classList.toggle("hidden", which !== "list");
}

document.getElementById("addBtn").onclick = () => {
  resetAddForm();
  document.getElementById("status").textContent = "";
  showView("add");
};
document.getElementById("cancelAddBtn").onclick = () => {
  resetAddForm();
  showView("list");
};

// ---- Flow step editor ----
// Step box: 1) Name, 2) XPath/CSS locator, 3) Input ya Click choice
const STEP_KINDS = [
  ["fill-user", "Input: Username"],
  ["fill-pass", "Input: Password"],
  ["fill-mfa", "Input: MFA Code"],
  ["click", "Click: Button"],
  ["wait", "Wait"]
];
function stepParamState(kind, paramInput) {
  paramInput.type = kind === "fill-pass" ? "password" : "text";
  if (kind === "wait") {
    paramInput.style.display = "";
    paramInput.placeholder = "ms, e.g. 2000";
    if (!paramInput.value) paramInput.value = "2000";
  } else if (kind === "click") {
    paramInput.style.display = "none";
    paramInput.value = "";
  } else if (kind === "fill-user") {
    paramInput.style.display = "";
    paramInput.placeholder = "Username / email yaha likho";
  } else if (kind === "fill-mfa") {
    paramInput.style.display = "";
    paramInput.placeholder = "MFA secret key (Base32) yaha likho";
  } else {
    paramInput.style.display = "";
    paramInput.placeholder = "Password yaha likho";
  }
}
function addStepRow(kind = "fill-user", name = "", selector = "", extra = "") {
  const box = document.getElementById("stepsList");
  const empty = box.querySelector(".step-empty");
  if (empty) empty.remove();
  const row = document.createElement("div");
  row.className = "step-row";
  row.draggable = true;
  // Mouse se drag-drop reorder
  row.addEventListener("dragstart", (e) => {
    try { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", "step"); } catch {}
    row.classList.add("dragging");
  });
  row.addEventListener("dragend", () => {
    row.classList.remove("dragging");
    box.querySelectorAll(".step-row").forEach((r) => r.classList.remove("drag-over", "drag-over-bottom"));
  });
  row.addEventListener("dragover", (e) => {
    e.preventDefault();
    const dragging = box.querySelector(".dragging");
    if (!dragging || dragging === row) return;
    const rect = row.getBoundingClientRect();
    const after = (e.clientY - rect.top) > rect.height / 2;
    box.querySelectorAll(".step-row").forEach((r) => r.classList.remove("drag-over", "drag-over-bottom"));
    row.classList.add(after ? "drag-over-bottom" : "drag-over");
  });
  row.addEventListener("drop", (e) => {
    e.preventDefault();
    const dragging = box.querySelector(".dragging");
    if (!dragging || dragging === row) return;
    const rect = row.getBoundingClientRect();
    const after = (e.clientY - rect.top) > rect.height / 2;
    box.insertBefore(dragging, after ? row.nextElementSibling : row);
    box.querySelectorAll(".step-row").forEach((r) => r.classList.remove("drag-over", "drag-over-bottom"));
  });
  // Line 1: grip + Name + delete
  const top = document.createElement("div");
  top.className = "step-top";
  const grip = document.createElement("span");
  grip.className = "step-grip";
  grip.textContent = "\u22ee\u22ee";
  grip.title = "Pakad kar drag karo";
  const nameInp = document.createElement("input");
  nameInp.type = "text"; nameInp.autocomplete = "off";
  nameInp.placeholder = "Step name, e.g. Username bharo";
  nameInp.value = name;
  const del = document.createElement("button");
  del.className = "step-mini"; del.type = "button"; del.textContent = "\u00d7"; del.title = "Hatao";
  del.onclick = () => {
    row.remove();
    if (!box.querySelector(".step-row")) box.innerHTML = '<div class="step-empty">Koi step nahi = auto flow (username, password, login).</div>';
  };
  top.appendChild(grip); top.appendChild(nameInp); top.appendChild(del);
  // Line 2: XPath / CSS locator
  const xpathInp = document.createElement("input");
  xpathInp.className = "step-xpath"; xpathInp.type = "text"; xpathInp.autocomplete = "off";
  xpathInp.placeholder = "XPath ya CSS locator (khali = auto-detect)";
  xpathInp.value = selector;
  // Line 3: Input/Click choice + value + up/down
  const bottom = document.createElement("div");
  bottom.className = "step-bottom";
  const sel = document.createElement("select");
  for (const [v, t] of STEP_KINDS) {
    const o = document.createElement("option");
    o.value = v; o.textContent = t;
    if (v === kind) o.selected = true;
    sel.appendChild(o);
  }
  const param = document.createElement("input");
  param.type = "text"; param.autocomplete = "off";
  param.value = extra;
  // MFA live preview: secret likhte hi us samay ka code yahi dikhega
  const preview = document.createElement("div");
  preview.className = "mfa-preview";
  preview.style.display = kind === "fill-mfa" ? "" : "none";
  preview.textContent = mfaPreviewText(extra);
  param.oninput = () => { if (sel.value === "fill-mfa") preview.textContent = mfaPreviewText(param.value); };
  sel.onchange = () => {
    stepParamState(sel.value, param);
    if (sel.value === "fill-mfa") { preview.style.display = ""; preview.textContent = mfaPreviewText(param.value); }
    else preview.style.display = "none";
  };
  stepParamState(kind, param);
  if (kind !== "wait" && !extra) param.value = "";
  const up = document.createElement("button");
  up.className = "step-mini"; up.type = "button"; up.textContent = "\u2191"; up.title = "Uppar";
  up.onclick = () => { if (row.previousElementSibling) box.insertBefore(row, row.previousElementSibling); };
  const down = document.createElement("button");
  down.className = "step-mini"; down.type = "button"; down.textContent = "\u2193"; down.title = "Neeche";
  down.onclick = () => { if (row.nextElementSibling) box.insertBefore(row.nextElementSibling, row); };
  bottom.appendChild(sel); bottom.appendChild(param);
  bottom.appendChild(up); bottom.appendChild(down);
  row.appendChild(top); row.appendChild(xpathInp); row.appendChild(bottom); row.appendChild(preview);
  box.appendChild(row);
}
function readStepsFromUI() {
  const steps = [];
  document.querySelectorAll("#stepsList .step-row").forEach((row) => {
    const kind = row.querySelector(".step-bottom select").value;
    const name = row.querySelector(".step-top input").value.trim();
    const selector = row.querySelector(".step-xpath").value.trim();
    const param = row.querySelector(".step-bottom input").value.trim();
    if (kind === "wait") {
      steps.push({ kind, name, ms: parseInt(param, 10) > 0 ? parseInt(param, 10) : 2000 });
    } else if (kind === "click") {
      steps.push({ kind, name, selector });
    } else {
      steps.push({ kind, name, selector, value: param });
    }
  });
  return steps;
}
function resetAddForm() {
  editingId = null;
  const saveBtn = document.getElementById("savePortalBtn");
  if (saveBtn) saveBtn.textContent = "Save Portal";
  for (const id of ["fName", "fUrl"]) {
    document.getElementById(id).value = "";
  }
  document.getElementById("stepsList").innerHTML = '<div class="step-empty">+ Add step dabakar flow banao (e.g. Username, Password, Login button).</div>';
}
document.getElementById("addStepBtn").onclick = () => addStepRow();
resetAddForm();

document.getElementById("savePortalBtn").onclick = async () => {
  const status = document.getElementById("status");
  const name = document.getElementById("fName").value.trim();
  let url = document.getElementById("fUrl").value.trim();
  if (!name || !url) {
    status.textContent = "Portal Name aur Website URL bharo.";
    return;
  }
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  try { new URL(url); } catch {
    status.textContent = "URL sahi nahi hai. e.g. https://example.com/login";
    return;
  }
  // Username + XPath steps se hi decide honge
  const steps = readStepsFromUI();
  if (!steps.length) {
    status.textContent = "+ Add step dabakar pehle flow banao (e.g. Username, Password, Login button).";
    return;
  }
  for (let i = 0; i < steps.length; i++) {
    const st = steps[i];
    if ((st.kind === "fill-user" || st.kind === "fill-pass") && !st.value) {
      status.textContent = `Step ${i + 1} ("${st.name || st.kind}") me bharne wali value likho.`;
      return;
    }
    if (st.kind === "fill-mfa") {
      if (!st.value) {
        status.textContent = `Step ${i + 1} ("${st.name || st.kind}") me MFA secret key likho.`;
        return;
      }
      if (!totpSecretOk(st.value)) {
        status.textContent = `Step ${i + 1} ("${st.name || st.kind}") me MFA secret sahi nahi hai (Base32: A-Z, 2-7).`;
        return;
      }
    }
  }
  const arr = await getCustomPortals();
  const record = {
    name, custom: true,
    loginUrl: url, homeUrl: url,
    username: "", password: "",
    userSelector: "", passSelector: "", submitSelector: "",
    steps
  };
  let wasEditing = false;
  if (editingId) {
    const ix = arr.findIndex((x) => x.id === editingId);
    if (ix !== -1) arr[ix] = { ...record, id: editingId };
    else arr.push({ ...record, id: editingId });
    wasEditing = true;
  } else {
    record.id = "custom_" + Date.now();
    arr.push(record);
  }
  await chrome.storage.local.set({ customPortals: arr });
  resetAddForm();
  renderList();
  // Wahi page par raho, sirf toast 2 sec dikhao
  const toast = document.getElementById("saveToast");
  if (toast) {
    toast.innerHTML = "&#10003; " + (wasEditing ? "Updated" : "Saved");
    toast.classList.remove("hidden");
    try { clearTimeout(toast._hideT); } catch {}
    toast._hideT = setTimeout(() => toast.classList.add("hidden"), 2000);
  }
  status.textContent = `"${name}" ` + (wasEditing ? "update ho gaya." : "save ho gaya.") + ` (flow: ${steps.length} steps)`;
};

// Tabs: sirf My Websites hai
document.getElementById("tabMine").onclick = () => {
  renderList();
};
// Pin button: popup me = permanent side-pin (toolbar click hamesha side kholega),
// side panel me = Unpin (wapas popup mode)
const sideBtn = document.getElementById("sideBtn");
if (sideBtn) {
  sideBtn.onclick = async () => {
    const status = document.getElementById("status");
    try {
      if (!chrome.sidePanel) throw new Error("ye Chrome version side panel support nahi karta (114+ chahiye)");
      if (IS_SIDE) {
        // Unpin: is tab ka panel band + toolbar wapas popup mode
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) await chrome.sidePanel.setOptions({ tabId: tabs[0].id, enabled: false });
        try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }); } catch {}
        await chrome.storage.local.set({ sidePinned: false });
        status.textContent = "Unpin ho gaya. Ab S logo dabane par popup khulega.";
        return;
      }
      await chrome.sidePanel.setOptions({ path: "sidepanel.html", enabled: true });
      try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch {}
      await chrome.storage.local.set({ sidePinned: true });
      const win = await chrome.windows.getCurrent();
      await chrome.sidePanel.open({ windowId: win.id });
      status.textContent = "Side me pin ho gaya. Ab S logo hamesha side me khulega (Unpin tak).";
    } catch (e) {
      status.textContent = "Pin fail: " + e.message;
    }
  };
}
// Search filter
const portalSearch = document.getElementById("portalSearch");
if (portalSearch) {
  portalSearch.addEventListener("input", () => {
    const q = portalSearch.value.trim().toLowerCase();
    document.querySelectorAll("#list .portal").forEach((r) => {
      const name = (r.querySelector(".pname")?.textContent || "").toLowerCase();
      r.style.display = !q || name.includes(q) ? "" : "none";
    });
  });
}
renderList();
