// Fill-only flow, NO backend, NO cookies.
// Credentials extension ke andar wali .env file se aate hai.
// Flow: Open click -> naya tab (login page) -> .env se username/password ->
// visible tab ke input fields me fill.

importScripts("portals.js");

// .env file ko padhkar object banata hai (comments/# aur khali lines skip)
async function loadEnv() {
  const url = chrome.runtime.getURL(".env");
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(".env file nahi mili extension folder me");
  const text = await res.text();
  const env = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const eq = line.indexOf("=");
    if (eq === -1) continue;
    env[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return env;
}

function waitForTabComplete(tabId, timeoutMs = 25000) {
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => {
      if (!done) { done = true; try { chrome.tabs.onUpdated.removeListener(listener); } catch {} resolve(false); }
    }, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        if (!done) { done = true; clearTimeout(timer); try { chrome.tabs.onUpdated.removeListener(listener); } catch {} resolve(true); }
      }
    }
    try { chrome.tabs.onUpdated.addListener(listener); } catch {}
    try {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) return;
        if (tab && tab.status === "complete" && !done) {
          done = true; clearTimeout(timer);
          try { chrome.tabs.onUpdated.removeListener(listener); } catch {}
          resolve(true);
        }
      });
    } catch {}
  });
}

// NOTE: ye function tab ke andar run hota hai, self-contained rakho.
function clickSubmitInPage(submitSel) {
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (!r || r.width < 2 || r.height < 2) return false;
    const st = window.getComputedStyle(el);
    return st && st.visibility !== "hidden" && st.display !== "none";
  }
  const sels = [];
  if (submitSel) sels.push(submitSel);
  sels.push('form button[type="submit"]', 'button[type="submit"]', 'form input[type="submit"]');
  const cands = [];
  for (const s of sels) {
    try {
      const t = String(s).trim();
      if (t.startsWith("/") || t.startsWith("(")) {
        const r = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        const one = r.singleNodeValue;
        if (one && visible(one) && !one.disabled) cands.push(one);
      } else {
        document.querySelectorAll(s).forEach((el) => { if (visible(el) && !el.disabled) cands.push(el); });
      }
    } catch {}
    if (cands.length) break;
  }
  if (!cands.length) return { clicked: false, reason: "button nahi mila" };
  // "Log in" jaisa text wala button prefer karo
  const keys = ["log in", "login", "sign in", "submit", "continue", "entrar", "anmelden"];
  let best = cands[0];
  for (const el of cands) {
    const t = ((el.innerText || el.value || "") + "").trim().toLowerCase();
    if (keys.some((k) => t.includes(k))) { best = el; break; }
  }
  try {
    best.scrollIntoView({ block: "center" });
    best.focus();
    best.click();
    return { clicked: true, text: ((best.innerText || best.value || "") + "").trim().slice(0, 30) };
  } catch (e) {
    return { clicked: false, reason: String((e && e.message) || e) };
  }
}

// NOTE: ye function tab ke andar run hota hai, self-contained rakho.
// Custom flow ka ek step chalata hai: fill-user / fill-pass / click.
function actInPage(step, username, password) {
  function findLoc(loc) {
    if (!loc) return null;
    const t = String(loc).trim();
    if (!t) return null;
    try {
      // XPath (/... ya (... se shuru) vs CSS selector
      if (t.startsWith("/") || t.startsWith("(")) {
        const r = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return r.singleNodeValue;
      }
      return document.querySelector(t);
    } catch { return null; }
  }
  function setVal(el, v) {
    if (!el) return false;
    try { el.scrollIntoView({ block: "center" }); } catch {}
    try { el.focus(); el.click(); } catch {}
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value")
        || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      const setter = desc && desc.set;
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
      if (setter && nativeSetter && setter !== nativeSetter) nativeSetter.call(el, v);
      else if (setter) setter.call(el, v);
      else el.value = v;
    } catch { try { el.value = v; } catch {} }
    try { el.dispatchEvent(new Event("input", { bubbles: true })); } catch {}
    try { el.dispatchEvent(new Event("change", { bubbles: true })); } catch {}
    return true;
  }
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (!r || r.width < 2 || r.height < 2) return false;
    try {
      const st = window.getComputedStyle(el);
      if (st && (st.visibility === "hidden" || st.display === "none")) return false;
    } catch {}
    return true;
  }
  function firstMatch(sels) {
    for (const s of sels) {
      let el = null;
      try { el = findLoc(s); } catch {}
      if (el && visible(el) && !el.disabled) return { el, sel: s };
    }
    return { el: null, sel: "" };
  }
  const kind = step.kind;
  if (kind === "fill-user" || kind === "fill-pass") {
    const isPass = kind === "fill-pass";
    // Step me khud value ho to wahi, warna portal ka username/password
    const val = (step.value && String(step.value).length) ? String(step.value)
      : (isPass ? password : username);
    const auto = isPass
      ? ['input[name="password"]', 'input[autocomplete="current-password"]', 'form input[type="password"]', 'input[type="password"]']
      : ['input[name="username"]', 'input[autocomplete="username"]', 'form input[type="text"]', 'input[type="text"]'];
    const sels = step.selector ? [step.selector, ...auto] : auto;
    const f = firstMatch(sels);
    if (!f.el) return { ok: false, name: step.name || "", reason: "field nahi mila", tried: sels.slice(0, 3) };
    setVal(f.el, val);
    return { ok: (f.el.value || "").length > 0, name: step.name || "", selector: f.sel, url: location.href };
  }
  if (kind === "click") {
    const found = [];
    if (step.selector) {
      const one = findLoc(step.selector);
      if (one && visible(one) && !one.disabled) found.push(one);
    } else {
      const sels = ['form button[type="submit"]', 'button[type="submit"]', 'form input[type="submit"]'];
      for (const s of sels) {
        try {
          document.querySelectorAll(s).forEach((el) => { if (visible(el) && !el.disabled) found.push(el); });
        } catch {}
        if (found.length) break;
      }
    }
    if (!found.length) return { ok: false, name: step.name || "", reason: "button nahi mila" };
    const keys = ["log in", "login", "sign in", "submit", "continue", "next", "verify"];
    let best = found[0];
    for (const el of found) {
      const t = ((el.innerText || el.value || "") + "").trim().toLowerCase();
      if (keys.some((k) => t.includes(k))) { best = el; break; }
    }
    try {
      best.scrollIntoView({ block: "center" });
      best.focus();
      best.click();
      return { ok: true, name: step.name || "", text: ((best.innerText || best.value || "") + "").trim().slice(0, 30) };
    } catch (e) {
      return { ok: false, name: step.name || "", reason: String((e && e.message) || e) };
    }
  }
  return { ok: false, name: step.name || "", reason: "unknown step: " + kind };
}

// Custom flow ke steps kram me chalata hai (har step element milne tak retry)
async function runSteps(tabId, steps, username, password) {
  const results = [];
  for (let i = 0; i < steps.length; i++) {
    const st = steps[i];
    if (st.kind === "wait") {
      await new Promise((r) => setTimeout(r, st.ms > 0 ? st.ms : 2000));
      results.push({ step: i + 1, kind: "wait", ok: true });
      continue;
    }
    let ok = false, last = null;
    for (let t = 0; t < 12; t++) {
      try {
        const r = await chrome.scripting.executeScript({
          target: { tabId },
          func: actInPage,
          args: [st, username, password]
        });
        last = r && r[0] && r[0].result;
        if (last && last.ok) { ok = true; break; }
      } catch (e) {
        last = { ok: false, error: e.message };
      }
      await new Promise((r) => setTimeout(r, 1000));
    }
    results.push({ step: i + 1, kind: st.kind, name: st.name || "", selector: st.selector || "auto", ok, detail: last });
    if (!ok) return { allOk: false, results };
  }
  return { allOk: true, results };
}

// NOTE: ye function tab ke andar run hota hai, self-contained rakho.
function fillInPage(username, password, userSel, passSel) {
  function findLoc(loc) {
    if (!loc) return null;
    const t = String(loc).trim();
    if (!t) return null;
    try {
      if (t.startsWith("/") || t.startsWith("(")) {
        const r = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return r.singleNodeValue;
      }
      return document.querySelector(t);
    } catch { return null; }
  }
  function setVal(el, v) {
    if (!el) return false;
    try { el.scrollIntoView({ block: "center" }); } catch {}
    try { el.focus(); el.click(); } catch {}
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value")
        || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      const setter = desc && desc.set;
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
      if (setter && nativeSetter && setter !== nativeSetter) nativeSetter.call(el, v);
      else if (setter) setter.call(el, v);
      else el.value = v;
    } catch { try { el.value = v; } catch {} }
    try { el.dispatchEvent(new Event("input", { bubbles: true })); } catch {}
    try { el.dispatchEvent(new Event("change", { bubbles: true })); } catch {}
    try { el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true })); } catch {}
    return true;
  }

  const userSelectors = [];
  if (userSel) userSelectors.push(userSel);
  userSelectors.push('input[name="username"]', 'input[autocomplete="username"]', 'form input[type="text"]', 'input[type="text"]');
  const passSelectors = [];
  if (passSel) passSelectors.push(passSel);
  passSelectors.push('input[name="password"]', 'input[autocomplete="current-password"]', 'form input[type="password"]', 'input[type="password"]');

  let u = null, p = null, usedU = "", usedP = "";
  for (const s of userSelectors) { try { u = findLoc(s); } catch {} if (u) { usedU = s; break; } }
  for (const s of passSelectors) { try { p = findLoc(s); } catch {} if (p) { usedP = s; break; } }

  const allInputs = Array.from(document.querySelectorAll("input")).map((el) => ({
    type: el.type, name: el.name, id: el.id, ph: (el.placeholder || "").slice(0, 40)
  }));

  const r1 = u ? setVal(u, username) : false;
  const r2 = p ? setVal(p, password) : false;

  return {
    url: location.href,
    title: document.title.slice(0, 80),
    userFound: !!u, passFound: !!p,
    usedU, usedP,
    userFilled: r1 && !!u && (u.value || "").length > 0,
    passFilled: r2 && !!p && (p.value || "").length > 0,
    inputCount: allInputs.length,
    inputs: allInputs.slice(0, 8)
  };
}

// Browser restart par pin wali setting wapas lagao
async function applyPinBehavior() {
  try {
    const data = await chrome.storage.local.get("sidePinned");
    if (data.sidePinned && chrome.sidePanel?.setPanelBehavior) {
      await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    }
  } catch {}
}
chrome.runtime.onStartup.addListener(applyPinBehavior);
chrome.runtime.onInstalled.addListener(applyPinBehavior);
applyPinBehavior();

async function getCustomPortal(id) {
  try {
    const data = await chrome.storage.local.get("customPortals");
    const arr = Array.isArray(data.customPortals) ? data.customPortals : [];
    return arr.find((p) => p.id === id) || null;
  } catch { return null; }
}

// Pehli baar sahi mile selectors yaha save hote hai (Instagram jaisa pakka)
async function getSelectorOverrides() {
  try {
    const data = await chrome.storage.local.get("selectorOverrides");
    return data.selectorOverrides && typeof data.selectorOverrides === "object"
      ? data.selectorOverrides : {};
  } catch { return {}; }
}

async function saveSelectorOverride(portalId, userSel, passSel, isCustom) {
  try {
    if (isCustom) {
      const data = await chrome.storage.local.get("customPortals");
      const arr = Array.isArray(data.customPortals) ? data.customPortals : [];
      const ix = arr.findIndex((p) => p.id === portalId);
      if (ix !== -1) {
        if (userSel) arr[ix].userSelector = userSel;
        if (passSel) arr[ix].passSelector = passSel;
        await chrome.storage.local.set({ customPortals: arr });
        return true;
      }
      return false;
    }
    const ov = await getSelectorOverrides();
    ov[portalId] = { userSelector: userSel || "", passSelector: passSel || "" };
    await chrome.storage.local.set({ selectorOverrides: ov });
    return true;
  } catch { return false; }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "AUTOLOGIN") return;
  (async () => {
    // Portal: pehle built-in (portals.js), phir custom (storage)
    const staticPortal = PORTALS[msg.portalId];
    const customPortal = staticPortal ? null : await getCustomPortal(msg.portalId);
    const portal = staticPortal || customPortal;
    if (!portal) { sendResponse({ ok: false, error: "unknown portal" }); return; }

    // 1. Naya tab kholo (popup se aye to background me taaki popup khula rahe)
    const tab = await chrome.tabs.create({ url: portal.loginUrl, active: !msg.openInBackground });

    // 2. Credentials lao: built-in -> .env file, custom -> storage (koi backend nahi)
    // Selectors: pehle save kiye hue (override), phir portals.js wale, phir generic guess
    let username = "", password = "";
    let userSel = portal.userSelector || "", passSel = portal.passSelector || "";
    if (staticPortal) {
      const ov = await getSelectorOverrides();
      if (ov[portal.id]?.userSelector) userSel = ov[portal.id].userSelector;
      if (ov[portal.id]?.passSelector) passSel = ov[portal.id].passSelector;
      let env;
      try {
        env = await loadEnv();
      } catch (e) {
        sendResponse({ ok: true, tabId: tab.id, mode: "open-only", warning: e.message });
        return;
      }
      username = env[portal.userEnv] || "";
      password = env[portal.passEnv] || "";
      if (!username || !password) {
        sendResponse({ ok: true, tabId: tab.id, mode: "open-only", warning: `${portal.userEnv}/${portal.passEnv} .env me khali hai. extension/.env me bharo.` });
        return;
      }
    } else {
      username = customPortal.username || "";
      password = customPortal.password || "";
      // Steps wale portal me value steps ke andar hoti hai, top-level khali chalega
      const hasSteps = Array.isArray(customPortal.steps) && customPortal.steps.length > 0;
      if (!hasSteps && (!username || !password)) {
        sendResponse({ ok: true, tabId: tab.id, mode: "open-only", warning: "Is portal ke creds khali hai. Delete karke dobara add karo." });
        return;
      }
    }

    // 3. Page load ka wait
    await waitForTabComplete(tab.id, 25000);
    await new Promise((r) => setTimeout(r, 2500));

    // 3b. Custom flow ho to steps kram me chalao (creator ka flow)
    if (Array.isArray(portal.steps) && portal.steps.length) {
      const flow = await runSteps(tab.id, portal.steps, username, password);
      if (flow.allOk) {
        sendResponse({ ok: true, tabId: tab.id, mode: "fill", flowSteps: flow.results.length, detail: { flow: flow.results } });
      } else {
        const bad = flow.results[flow.results.length - 1];
        sendResponse({
          ok: true, tabId: tab.id, mode: "open-only",
          warning: `Flow step ${bad.step}${bad.name ? ` ("${bad.name}")` : ` (${bad.kind})`} fail. selector="${bad.selector || ""}" ` +
            (bad.detail?.reason ? "reason=" + bad.detail.reason : "") +
            (bad.detail?.error ? " err=" + bad.detail.error : "")
        });
      }
      return;
    }

    // 4. Retry ke saath fill karo
    let last = null;
    for (let i = 0; i < 8; i++) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: fillInPage,
          args: [username, password, userSel, passSel]
        });
        last = results && results[0] && results[0].result;
        if (last && last.userFilled && last.passFilled) {
          // Sahi selectors mile -> save kar lo taaki agli baar pakka kaam kare
          let saved = false;
          if (last.usedU || last.usedP) {
            saved = await saveSelectorOverride(msg.portalId, last.usedU, last.usedP, !staticPortal);
          }
          // Fill ke baad Login button khud dabao
          let submitted = null;
          try {
            await new Promise((r) => setTimeout(r, 1200));
            const cr = await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: clickSubmitInPage,
              args: [portal.submitSelector || ""]
            });
            submitted = cr && cr[0] && cr[0].result;
          } catch (e) {
            submitted = { clicked: false, reason: e.message };
          }
          sendResponse({ ok: true, tabId: tab.id, mode: "fill", detail: last, selectorsSaved: saved, submitted });
          return;
        }
      } catch (e) {
        last = { error: e.message, url: portal.loginUrl };
      }
      await new Promise((r) => setTimeout(r, 2000));
    }

    sendResponse({
      ok: true, tabId: tab.id, mode: "open-only",
      warning: "Field fill nahi hua. userFound=" + (last?.userFound) +
        " passFound=" + (last?.passFound) +
        " inputs=" + (last?.inputCount ?? "?") +
        " url=" + (last?.url || "?") +
        (last?.error ? " err=" + last.error : "")
    });
  })().catch((err) => {
    try { sendResponse({ ok: false, error: String((err && err.message) || err) }); } catch {}
  });
  return true;
});
