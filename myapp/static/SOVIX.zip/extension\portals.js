// Built-in portal list. Khali hai taaki kisi bhi naye laptop par
// pehle se koi portal na dikhe.
// Apne portal + dabakar add karo (username / password / MFA steps ke saath).
const PORTALS = {};
