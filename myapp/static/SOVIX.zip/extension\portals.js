// Portal list + selectors. Naya portal add karna ho to yaha entry + .env me user/pass.
const PORTALS = {
  instagram: {
    id: "instagram",
    name: "Instagram",
    loginUrl: "https://www.instagram.com/accounts/login/",
    homeUrl: "https://www.instagram.com/",
    userEnv: "INSTAGRAM_USER",
    passEnv: "INSTAGRAM_PASS",
    userSelector: 'input[name="username"]',
    passSelector: 'input[name="password"]'
  }
};
