SOVIX PortalLogin - friend setup (koi command nahi)

1. Ye folder kahin rakho. extension\.env Notepad me kholo, apna INSTAGRAM_USER / INSTAGRAM_PASS bharo, save karo.
2. Chrome me chrome://extensions kholo -> Developer mode (upar right) ON -> Load unpacked -> is pack ka extension folder select karo.
3. Toolbar me S logo dabao (puzzle menu se pin kar lo) -> Instagram row par click -> naya tab khulkar username/password bhar jayega.
4. Naya portal: header me + dabao -> Portal Name + Website URL -> + Add step se steps banao (Name + XPath + Input/Click) -> Save Portal. Row par aankh=View, pencil=Edit, kachra=Delete.

Note: .env me badlav ke baad extension par Reload dabana padta hai. .env kisi ko bhejo mat.

