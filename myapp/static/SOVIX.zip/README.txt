SOVIX PortalLogin - friend setup (koi command nahi)

1. Chrome me chrome://extensions kholo -> Developer mode (upar right) ON -> Load unpacked -> is pack ka extension folder select karo.
2. Toolbar me S logo dabao (puzzle menu se pin kar lo) -> pehli baar list khali hogi (koi default portal nahi aata).
3. Naya portal: header me + dabao -> Portal Name + Website URL -> + Add step se steps banao:
   - Input: Username -> username/email + XPath (khali = auto-detect)
   - Input: Password -> password + XPath
   - Input: MFA Code -> MFA secret key (Base32) likho, us samay ka 6-digit code neeche live dikhega, login par OTP field me auto-bharega
   - Click: Button -> Login button, Wait -> rukna (ms)
   -> Save Portal. Row par aankh=View, pencil=Edit, kachra=Delete.
4. Portal row par click -> naya tab khulkar fields bhar jayenge (MFA code us samay ka fresh).

Note: extension/.env optional hai. Custom portals isi laptop ke chrome.storage me rehte hai, kisi ko bhejo mat.


