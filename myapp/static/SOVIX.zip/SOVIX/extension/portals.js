// Built-in portal list. Empty so that no portal is shown on a fresh machine.
// Add your own portal with the + button (with username / password / MFA steps).
const PORTALS = {};

// ── Per-portal env keys ──
// Portal Name "outlook" -> outlook_username, outlook_password, outlook_mfa
// "My Office Portal" -> my_office_portal_username, ...
// NOTE: the packaged .env file cannot be written at extension runtime (MV3 read-only),
// so these keys are saved like a .env in chrome.storage.local "envCreds".
function portalSlug(name) {
  let s = String(name || "").trim().toLowerCase();
  s = s.replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  if (!s) s = "portal";
  if (/^[0-9]/.test(s)) s = "p_" + s;
  return s.slice(0, 48);
}
function portalEnvKeys(name) {
  const slug = portalSlug(name);
  return {
    slug: slug,
    user: slug + "_username",
    pass: slug + "_password",
    mfa: slug + "_mfa"
  };
}
