// Fill-only flow, NO backend, NO cookies. Credentials come from the extension's .env file / per-portal storage.
// Flow: click Open -> new tab (login page) -> fill visible input fields.

importScripts("portals.js");

// ── TOTP (RFC 6238, SHA1, 30s, 6-digit) — no dependencies ──
// In the MFA step the user enters the secret key (Base32); this generates the
// current 6-digit code which is filled into the page's OTP field.
function totpBase32Decode(s) {
  const alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const clean = String(s || "").toUpperCase().replace(/[^A-Z2-7]/g, "");
  let bits = 0, val = 0;
  const out = [];
  for (const ch of clean) {
    val = (val << 5) | alpha.indexOf(ch);
    bits += 5;
    if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
  }
  return out;
}
function totpSha1(bytes) {
  let h0 = 0x67452301, h1 = 0xEFCDAB89, h2 = 0x98BADCFE, h3 = 0x10325476, h4 = 0xC3D2E1F0;
  const msg = bytes.slice();
  const bitLen = msg.length * 8;
  msg.push(0x80);
  while (msg.length % 64 !== 56) msg.push(0);
  const hi = Math.floor(bitLen / 0x100000000), lo = bitLen >>> 0;
  msg.push((hi >>> 24) & 255, (hi >>> 16) & 255, (hi >>> 8) & 255, hi & 255,
           (lo >>> 24) & 255, (lo >>> 16) & 255, (lo >>> 8) & 255, lo & 255);
  const w = new Array(80);
  const rol = (n, s) => ((n << s) | (n >>> (32 - s))) >>> 0;
  for (let i = 0; i < msg.length; i += 64) {
    for (let t = 0; t < 16; t++) w[t] = ((msg[i + t * 4] << 24) | (msg[i + t * 4 + 1] << 16) | (msg[i + t * 4 + 2] << 8) | msg[i + t * 4 + 3]) >>> 0;
    for (let t = 16; t < 80; t++) w[t] = rol(w[t - 3] ^ w[t - 8] ^ w[t - 14] ^ w[t - 16], 1);
    let a = h0, b = h1, c = h2, d = h3, e = h4;
    for (let t = 0; t < 80; t++) {
      let f, k;
      if (t < 20) { f = (b & c) | ((~b) & d); k = 0x5A827999; }
      else if (t < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
      else if (t < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
      else { f = b ^ c ^ d; k = 0xCA62C1D6; }
      const tmp = (rol(a, 5) + f + e + k + w[t]) >>> 0;
      e = d; d = c; c = rol(b, 30); b = a; a = tmp;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0; h4 = (h4 + e) >>> 0;
  }
  const out = [];
  for (const h of [h0, h1, h2, h3, h4]) out.push((h >>> 24) & 255, (h >>> 16) & 255, (h >>> 8) & 255, h & 255);
  return out;
}
function totpHmacSha1(key, msg) {
  let k = key.slice();
  if (k.length > 64) k = totpSha1(k);
  while (k.length < 64) k.push(0);
  const ipad = k.map((b) => b ^ 0x36), opad = k.map((b) => b ^ 0x5c);
  return totpSha1(opad.concat(totpSha1(ipad.concat(msg))));
}
function totpGenerate(secret, nowMs) {
  const key = totpBase32Decode(secret);
  if (!key.length) return "";
  const counter = Math.floor((nowMs || Date.now()) / 30000);
  const msg = [0, 0, 0, 0, (counter >>> 24) & 255, (counter >>> 16) & 255, (counter >>> 8) & 255, counter & 255];
  const h = totpHmacSha1(key, msg);
  const off = h[h.length - 1] & 15;
  const code = ((h[off] & 127) << 24) | (h[off + 1] << 16) | (h[off + 2] << 8) | h[off + 3];
  return String(code % 1000000).padStart(6, "0");
}

// Reads the .env file into an object (skips comments/# and blank lines)
async function loadEnv() {
  const url = chrome.runtime.getURL(".env");
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(".env file not found in the extension folder");
  const text = await res.text();
  const env = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const eq = line.indexOf("=");
    if (eq === -1) continue;
    env[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return env;
}

function waitForTabComplete(tabId, timeoutMs = 25000) {
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => {
      if (!done) { done = true; try { chrome.tabs.onUpdated.removeListener(listener); } catch {} resolve(false); }
    }, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        if (!done) { done = true; clearTimeout(timer); try { chrome.tabs.onUpdated.removeListener(listener); } catch {} resolve(true); }
      }
    }
    try { chrome.tabs.onUpdated.addListener(listener); } catch {}
    try {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) return;
        if (tab && tab.status === "complete" && !done) {
          done = true; clearTimeout(timer);
          try { chrome.tabs.onUpdated.removeListener(listener); } catch {}
          resolve(true);
        }
      });
    } catch {}
  });
}

// NOTE: this function runs inside the tab, keep it self-contained.
function clickSubmitInPage(submitSel) {
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (!r || r.width < 2 || r.height < 2) return false;
    const st = window.getComputedStyle(el);
    return st && st.visibility !== "hidden" && st.display !== "none";
  }
  const sels = [];
  if (submitSel) sels.push(submitSel);
  sels.push('form button[type="submit"]', 'button[type="submit"]', 'form input[type="submit"]');
  const cands = [];
  for (const s of sels) {
    try {
      const t = String(s).trim();
      if (t.startsWith("/") || t.startsWith("(")) {
        const r = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        const one = r.singleNodeValue;
        if (one && visible(one) && !one.disabled) cands.push(one);
      } else {
        document.querySelectorAll(s).forEach((el) => { if (visible(el) && !el.disabled) cands.push(el); });
      }
    } catch {}
    if (cands.length) break;
  }
  if (!cands.length) return { clicked: false, reason: "button not found" };
  // Prefer a button with text like "Log in"
  const keys = ["log in", "login", "sign in", "submit", "continue", "entrar", "anmelden"];
  let best = cands[0];
  for (const el of cands) {
    const t = ((el.innerText || el.value || "") + "").trim().toLowerCase();
    if (keys.some((k) => t.includes(k))) { best = el; break; }
  }
  try {
    best.scrollIntoView({ block: "center" });
    best.focus();
    best.click();
    return { clicked: true, text: ((best.innerText || best.value || "") + "").trim().slice(0, 30) };
  } catch (e) {
    return { clicked: false, reason: String((e && e.message) || e) };
  }
}

// NOTE: this function runs inside the tab, keep it self-contained.
// Runs one step of the custom flow: fill-user / fill-pass / click.
function actInPage(step, username, password) {
  function findLoc(loc) {
    if (!loc) return null;
    const t = String(loc).trim();
    if (!t) return null;
    try {
      // XPath (starting with /... or () vs CSS selector
      if (t.startsWith("/") || t.startsWith("(")) {
        const r = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return r.singleNodeValue;
      }
      return document.querySelector(t);
    } catch { return null; }
  }
  function setVal(el, v) {
    if (!el) return false;
    try { el.scrollIntoView({ block: "center" }); } catch {}
    // Green outline for 2.5 sec: show the user which field was filled
    try {
      const _old = el.style.outline;
      el.style.outline = "3px solid #22a35c"; el.style.outlineOffset = "2px";
      setTimeout(() => { try { el.style.outline = _old; } catch {} }, 2500);
    } catch {}
    try { el.focus(); el.click(); } catch {}
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value")
        || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      const setter = desc && desc.set;
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
      if (setter && nativeSetter && setter !== nativeSetter) nativeSetter.call(el, v);
      else if (setter) setter.call(el, v);
      else el.value = v;
    } catch { try { el.value = v; } catch {} }
    try { el.dispatchEvent(new Event("input", { bubbles: true })); } catch {}
    try { el.dispatchEvent(new Event("change", { bubbles: true })); } catch {}
    return true;
  }
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (!r || r.width < 2 || r.height < 2) return false;
    try {
      const st = window.getComputedStyle(el);
      if (st && (st.visibility === "hidden" || st.display === "none")) return false;
    } catch {}
    return true;
  }
  function firstMatch(sels) {
    for (const s of sels) {
      let el = null;
      try { el = findLoc(s); } catch {}
      if (el && visible(el) && !el.disabled) return { el, sel: s };
    }
    return { el: null, sel: "" };
  }
  const kind = step.kind;
  if (kind === "fill-user" || kind === "fill-pass") {
    const isPass = kind === "fill-pass";
    // Use the step's own value if present, otherwise the portal username/password
    const val = (step.value && String(step.value).length) ? String(step.value)
      : (isPass ? password : username);
    const auto = isPass
      ? ['input[name="password"]', 'input[autocomplete="current-password"]', 'form input[type="password"]', 'input[type="password"]']
      : ['input[name="username"]', 'input[autocomplete="username"]', 'form input[type="text"]', 'input[type="text"]'];
    const sels = step.selector ? [step.selector, ...auto] : auto;
    const f = firstMatch(sels);
    if (!f.el) return { ok: false, name: step.name || "", reason: "field not found", tried: sels.slice(0, 3) };
    setVal(f.el, val);
    return { ok: (f.el.value || "").length > 0, name: step.name || "", selector: f.sel, url: location.href };
  }
  if (kind === "fill-mfa") {
    // MFA: step.value holds the secret key, fill the current TOTP code.
    // The code is generated in advance in runSteps and passed via step.totpCode.
    const val = (step.totpCode != null && String(step.totpCode).length) ? String(step.totpCode) : "";
    if (!val) return { ok: false, name: step.name || "", reason: "MFA code not generated" };
    const auto = ['input[autocomplete="one-time-code"]', 'input[name="otp"]', 'input[name="totp"]',
      'input[name="mfa"]', 'input[name="code"]', 'input[inputmode="numeric"]',
      'input[type="tel"]', 'input[type="number"]', 'input[type="text"]'];
    const sels = step.selector ? [step.selector, ...auto] : auto;
    const f = firstMatch(sels);
    if (!f.el) return { ok: false, name: step.name || "", reason: "MFA field not found", tried: sels.slice(0, 3) };
    setVal(f.el, val);
    return { ok: (f.el.value || "").length > 0, name: step.name || "", selector: f.sel, url: location.href };
  }
  if (kind === "click") {
    const found = [];
    if (step.selector) {
      const one = findLoc(step.selector);
      if (one && visible(one) && !one.disabled) found.push(one);
    } else {
      const sels = ['form button[type="submit"]', 'button[type="submit"]', 'form input[type="submit"]'];
      for (const s of sels) {
        try {
          document.querySelectorAll(s).forEach((el) => { if (visible(el) && !el.disabled) found.push(el); });
        } catch {}
        if (found.length) break;
      }
    }
    if (!found.length) return { ok: false, name: step.name || "", reason: "button not found" };
    const keys = ["log in", "login", "sign in", "submit", "continue", "next", "verify"];
    let best = found[0];
    for (const el of found) {
      const t = ((el.innerText || el.value || "") + "").trim().toLowerCase();
      if (keys.some((k) => t.includes(k))) { best = el; break; }
    }
    try {
      best.scrollIntoView({ block: "center" });
      try {
        const _o = best.style.outline;
        best.style.outline = "3px solid #22a35c"; best.style.outlineOffset = "2px";
        setTimeout(() => { try { best.style.outline = _o; } catch {} }, 2500);
      } catch {}
      best.focus();
      best.click();
      return { ok: true, name: step.name || "", text: ((best.innerText || best.value || "") + "").trim().slice(0, 30) };
    } catch (e) {
      return { ok: false, name: step.name || "", reason: String((e && e.message) || e) };
    }
  }
  return { ok: false, name: step.name || "", reason: "unknown step: " + kind };
}

// Runs the custom flow steps in order (retries each step until the element is found)
async function runSteps(tabId, steps, username, password) {
  const results = [];
  for (let i = 0; i < steps.length; i++) {
    const st = steps[i];
    if (st.kind === "wait") {
      await new Promise((r) => setTimeout(r, st.ms > 0 ? st.ms : 2000));
      results.push({ step: i + 1, kind: "wait", ok: true });
      continue;
    }
    if (st.kind === "wait-url") {
      // Multi-page login: wait until the URL contains this text (max 15 sec)
      const exp = String(st.expect || "").trim().toLowerCase();
      let ok = !exp;
      const t0 = Date.now();
      while (!ok && Date.now() - t0 < 15000) {
        try {
          const t = await chrome.tabs.get(tabId);
          if (t && t.url && t.url.toLowerCase().includes(exp)) ok = true;
        } catch {}
        if (!ok) await new Promise((r) => setTimeout(r, 1000));
      }
      results.push({ step: i + 1, kind: "wait-url", name: st.name || "", expect: st.expect || "", ok });
      if (!ok) return { allOk: false, results };
      continue;
    }
    let ok = false, last = null;
    for (let t = 0; t < 12; t++) {
      // MFA step: generate a fresh TOTP code on every retry (the 30s window may change)
      let eff = st;
      if (st.kind === "fill-mfa") {
        const code = totpGenerate(st.value, Date.now());
        if (!code) { last = { ok: false, reason: "invalid MFA secret" }; break; }
        eff = { ...st, totpCode: code };
      }
      try {
        const r = await chrome.scripting.executeScript({
          target: { tabId },
          func: actInPage,
          args: [eff, username, password]
        });
        last = r && r[0] && r[0].result;
        if (last && last.ok) { ok = true; break; }
      } catch (e) {
        last = { ok: false, error: e.message };
      }
      await new Promise((r) => setTimeout(r, 1000));
    }
    results.push({ step: i + 1, kind: st.kind, name: st.name || "", selector: st.selector || "auto", ok, detail: last });
    if (!ok) return { allOk: false, results };
  }
  return { allOk: true, results };
}

// NOTE: this function runs inside the tab, keep it self-contained.
function fillInPage(username, password, userSel, passSel) {
  function findLoc(loc) {
    if (!loc) return null;
    const t = String(loc).trim();
    if (!t) return null;
    try {
      if (t.startsWith("/") || t.startsWith("(")) {
        const r = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return r.singleNodeValue;
      }
      return document.querySelector(t);
    } catch { return null; }
  }
  function setVal(el, v) {
    if (!el) return false;
    try { el.scrollIntoView({ block: "center" }); } catch {}
    try {
      const _old = el.style.outline;
      el.style.outline = "3px solid #22a35c"; el.style.outlineOffset = "2px";
      setTimeout(() => { try { el.style.outline = _old; } catch {} }, 2500);
    } catch {}
    try { el.focus(); el.click(); } catch {}
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value")
        || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      const setter = desc && desc.set;
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
      if (setter && nativeSetter && setter !== nativeSetter) nativeSetter.call(el, v);
      else if (setter) setter.call(el, v);
      else el.value = v;
    } catch { try { el.value = v; } catch {} }
    try { el.dispatchEvent(new Event("input", { bubbles: true })); } catch {}
    try { el.dispatchEvent(new Event("change", { bubbles: true })); } catch {}
    try { el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true })); } catch {}
    return true;
  }

  const userSelectors = [];
  if (userSel) userSelectors.push(userSel);
  userSelectors.push('input[name="username"]', 'input[autocomplete="username"]', 'form input[type="text"]', 'input[type="text"]');
  const passSelectors = [];
  if (passSel) passSelectors.push(passSel);
  passSelectors.push('input[name="password"]', 'input[autocomplete="current-password"]', 'form input[type="password"]', 'input[type="password"]');

  let u = null, p = null, usedU = "", usedP = "";
  for (const s of userSelectors) { try { u = findLoc(s); } catch {} if (u) { usedU = s; break; } }
  for (const s of passSelectors) { try { p = findLoc(s); } catch {} if (p) { usedP = s; break; } }

  const allInputs = Array.from(document.querySelectorAll("input")).map((el) => ({
    type: el.type, name: el.name, id: el.id, ph: (el.placeholder || "").slice(0, 40)
  }));

  const r1 = u ? setVal(u, username) : false;
  const r2 = p ? setVal(p, password) : false;

  return {
    url: location.href,
    title: document.title.slice(0, 80),
    userFound: !!u, passFound: !!p,
    usedU, usedP,
    userFilled: r1 && !!u && (u.value || "").length > 0,
    passFilled: r2 && !!p && (p.value || "").length > 0,
    inputCount: allInputs.length,
    inputs: allInputs.slice(0, 8)
  };
}

// Re-apply the pinned setting on browser restart
async function applyPinBehavior() {
  try {
    const data = await chrome.storage.local.get("sidePinned");
    if (data.sidePinned && chrome.sidePanel?.setPanelBehavior) {
      await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    }
  } catch {}
}
chrome.runtime.onStartup.addListener(applyPinBehavior);
chrome.runtime.onInstalled.addListener(applyPinBehavior);
applyPinBehavior();

// Keyboard shortcut (Ctrl+Shift+L): open the SOVIX side panel
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "open-side-panel") return;
  try {
    await chrome.sidePanel.setOptions({ path: "sidepanel.html", enabled: true });
  } catch {}
  try {
    const win = await chrome.windows.getLastFocused();
    if (win && win.id != null) {
      await chrome.sidePanel.open({ windowId: win.id });
      // Opened via shortcut = pin mode ON (the S icon will open the side panel from now on)
      try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch {}
      await chrome.storage.local.set({ sidePinned: true });
    }
  } catch {}
});

async function getCustomPortal(id) {
  try {
    const data = await chrome.storage.local.get("customPortals");
    const arr = Array.isArray(data.customPortals) ? data.customPortals : [];
    return arr.find((p) => p.id === id) || null;
  } catch { return null; }
}

// Selectors found correct the first time are saved here (so it works reliably next time)
async function getSelectorOverrides() {
  try {
    const data = await chrome.storage.local.get("selectorOverrides");
    return data.selectorOverrides && typeof data.selectorOverrides === "object"
      ? data.selectorOverrides : {};
  } catch { return {}; }
}

async function saveSelectorOverride(portalId, userSel, passSel, isCustom) {
  try {
    if (isCustom) {
      const data = await chrome.storage.local.get("customPortals");
      const arr = Array.isArray(data.customPortals) ? data.customPortals : [];
      const ix = arr.findIndex((p) => p.id === portalId);
      if (ix !== -1) {
        if (userSel) arr[ix].userSelector = userSel;
        if (passSel) arr[ix].passSelector = passSel;
        await chrome.storage.local.set({ customPortals: arr });
        return true;
      }
      return false;
    }
    const ov = await getSelectorOverrides();
    ov[portalId] = { userSelector: userSel || "", passSelector: passSel || "" };
    await chrome.storage.local.set({ selectorOverrides: ov });
    return true;
  } catch { return false; }
}

// NOTE: this function runs inside the tab, keep it self-contained.
// Returns a unique CSS selector for the element the user clicks on the page.
// Esc or 60 sec timeout = cancel.
function pickSelectorInPage() {
  return new Promise((resolve) => {
    try {
      const style = document.createElement("style");
      style.textContent = ".__sovix_hover{outline:3px solid #4b2b8f !important;outline-offset:2px !important;cursor:crosshair !important;}";
      document.documentElement.appendChild(style);
      let cur = null, done = false;
      function cleanup() {
        try { document.removeEventListener("mouseover", onOver, true); } catch {}
        try { document.removeEventListener("click", onClick, true); } catch {}
        try { document.removeEventListener("keydown", onKey, true); } catch {}
        try { if (cur) cur.classList.remove("__sovix_hover"); } catch {}
        try { style.remove(); } catch {}
      }
      function cssSel(el) {
        try {
          if (el.id) return "#" + CSS.escape(el.id);
          const parts = [];
          let n = el;
          while (n && n !== document.body && parts.length < 4) {
            let s = n.tagName.toLowerCase();
            if (n.getAttribute && n.getAttribute("name")) {
              s += '[name="' + String(n.getAttribute("name")).replace(/"/g, "") + '"]';
            } else if (n.getAttribute && n.getAttribute("type")) {
              s += '[type="' + String(n.getAttribute("type")) + '"]';
            } else if (n.parentNode) {
              const sib = Array.prototype.filter.call(n.parentNode.children, (e) => e.tagName === n.tagName);
              if (sib.length > 1) s += ":nth-of-type(" + (sib.indexOf(n) + 1) + ")";
            }
            parts.unshift(s);
            n = n.parentNode;
            try { if (document.querySelectorAll(parts.join(" ")).length === 1) break; } catch {}
          }
          return parts.join(" ");
        } catch { return ""; }
      }
      function onOver(e) {
        try {
          if (cur) cur.classList.remove("__sovix_hover");
          cur = e.target;
          cur.classList.add("__sovix_hover");
        } catch {}
      }
      function onClick(e) {
        e.preventDefault(); e.stopPropagation();
        if (done) return; done = true;
        const s = cssSel(e.target);
        cleanup();
        resolve({ selector: s });
      }
      function onKey(e) {
        if (e.key === "Escape") {
          if (done) return; done = true;
          cleanup();
          resolve({ cancelled: true });
        }
      }
      document.addEventListener("mouseover", onOver, true);
      document.addEventListener("click", onClick, true);
      document.addEventListener("keydown", onKey, true);
      setTimeout(() => {
        if (done) return; done = true;
        cleanup();
        resolve({ cancelled: true, timeout: true });
      }, 60000);
    } catch (err) {
      try { resolve({ selector: "", error: String((err && err.message) || err) }); } catch {}
    }
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Pick an element from the page (the step form's ⌖ button)
  if (msg && msg.type === "PICK_SELECTOR") {
    (async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tab = tabs && tabs[0];
      if (!tab || !tab.id) { sendResponse({ cancelled: true, error: "no active tab" }); return; }
      try {
        const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pickSelectorInPage });
        const out = r && r[0] && r[0].result;
        sendResponse(out || { cancelled: true });
      } catch (e) {
        sendResponse({ cancelled: true, error: String((e && e.message) || e) });
      }
    })().catch((err) => {
      try { sendResponse({ cancelled: true, error: String((err && err.message) || err) }); } catch {}
    });
    return true;
  }
  if (!msg || msg.type !== "AUTOLOGIN") return;
  (async () => {
    // Portal: first built-in (portals.js), then custom (storage)
    const staticPortal = PORTALS[msg.portalId];
    const customPortal = staticPortal ? null : await getCustomPortal(msg.portalId);
    const portal = staticPortal || customPortal;
    if (!portal) { sendResponse({ ok: false, error: "unknown portal" }); return; }

    // 1. Open a new tab (in the background if launched from the popup so the popup stays open)
    const tab = await chrome.tabs.create({ url: portal.loginUrl, active: !msg.openInBackground });

    // 2. Load credentials: built-in -> .env file, custom -> per-portal virtual .env (envCreds)
    // e.g. Instagram -> instagram_username, instagram_password, instagram_mfa
    // Selectors: first the saved ones (override), then the portals.js ones, then a generic guess
    let username = "", password = "";
    let effSteps = Array.isArray(portal.steps) ? portal.steps : null;
    let userSel = portal.userSelector || "", passSel = portal.passSelector || "";
    if (staticPortal) {
      const ov = await getSelectorOverrides();
      if (ov[portal.id]?.userSelector) userSel = ov[portal.id].userSelector;
      if (ov[portal.id]?.passSelector) passSel = ov[portal.id].passSelector;
      let env;
      try {
        env = await loadEnv();
      } catch (e) {
        sendResponse({ ok: true, tabId: tab.id, mode: "open-only", warning: e.message });
        return;
      }
      username = env[portal.userEnv] || "";
      password = env[portal.passEnv] || "";
      if (!username || !password) {
        sendResponse({ ok: true, tabId: tab.id, mode: "open-only", warning: `${portal.userEnv}/${portal.passEnv} missing in .env. Add them in extension/.env.` });
        return;
      }
    } else {
      // Read from per-portal env keys, fallback to legacy data (top-level / steps value)
      let envStore = {};
      try {
        const d = await chrome.storage.local.get("envCreds");
        if (d.envCreds && typeof d.envCreds === "object") envStore = d.envCreds;
      } catch {}
      let eKeys = null;
      try {
        eKeys = (typeof portalEnvKeys === "function")
          ? portalEnvKeys(customPortal.name || "")
          : null;
      } catch {}
      if (!eKeys && customPortal.envKeys) {
        eKeys = { user: customPortal.envKeys.user, pass: customPortal.envKeys.pass, mfa: customPortal.envKeys.mfa };
      }
      function stepVal(kind) {
        for (const s of (customPortal.steps || [])) {
          if (s && s.kind === kind && String(s.value || "").length) return String(s.value);
        }
        return "";
      }
      username = (eKeys && envStore[eKeys.user]) || customPortal.username || stepVal("fill-user") || "";
      password = (eKeys && envStore[eKeys.pass]) || customPortal.password || stepVal("fill-pass") || "";
      // MFA secret also from env (fresh TOTP is generated in runSteps)
      const mfaSecret = (eKeys && envStore[eKeys.mfa]) || stepVal("fill-mfa") || "";
      if (mfaSecret && Array.isArray(customPortal.steps)) {
        effSteps = customPortal.steps.map((s) =>
          (s && s.kind === "fill-mfa" ? { ...s, value: mfaSecret } : s)
        );
      }
      // For a steps-based portal the value lives inside steps/env, top-level may stay empty
      const hasSteps = Array.isArray(customPortal.steps) && customPortal.steps.length > 0;
      if (!hasSteps && (!username || !password)) {
        sendResponse({ ok: true, tabId: tab.id, mode: "open-only", warning: "This portal has no saved credentials. Delete it and add it again." });
        return;
      }
    }

    // 3. Wait for the page to load
    await waitForTabComplete(tab.id, 25000);
    await new Promise((r) => setTimeout(r, 2500));

    // 3b. If there is a custom flow, run the steps in order (creator's flow, env-resolved)
    if (Array.isArray(effSteps) && effSteps.length) {
      const flow = await runSteps(tab.id, effSteps, username, password);
      if (flow.allOk) {
        sendResponse({ ok: true, tabId: tab.id, mode: "fill", flowSteps: flow.results.length, detail: { flow: flow.results } });
      } else {
        const bad = flow.results[flow.results.length - 1];
        sendResponse({
          ok: true, tabId: tab.id, mode: "open-only",
          warning: `Flow step ${bad.step}${bad.name ? ` ("${bad.name}")` : ` (${bad.kind})`} failed. selector="${bad.selector || ""}" ` +
            (bad.detail?.reason ? "reason=" + bad.detail.reason : "") +
            (bad.detail?.error ? " err=" + bad.detail.error : "")
        });
      }
      return;
    }

    // 4. Fill with retries
    let last = null;
    for (let i = 0; i < 8; i++) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: fillInPage,
          args: [username, password, userSel, passSel]
        });
        last = results && results[0] && results[0].result;
        if (last && last.userFilled && last.passFilled) {
          // Found correct selectors -> save them so it works reliably next time
          let saved = false;
          if (last.usedU || last.usedP) {
            saved = await saveSelectorOverride(msg.portalId, last.usedU, last.usedP, !staticPortal);
          }
          // After filling, click the Login button automatically
          let submitted = null;
          try {
            await new Promise((r) => setTimeout(r, 1200));
            const cr = await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: clickSubmitInPage,
              args: [portal.submitSelector || ""]
            });
            submitted = cr && cr[0] && cr[0].result;
          } catch (e) {
            submitted = { clicked: false, reason: e.message };
          }
          sendResponse({ ok: true, tabId: tab.id, mode: "fill", detail: last, selectorsSaved: saved, submitted });
          return;
        }
      } catch (e) {
        last = { error: e.message, url: portal.loginUrl };
      }
      await new Promise((r) => setTimeout(r, 2000));
    }

    sendResponse({
      ok: true, tabId: tab.id, mode: "open-only",
      warning: "Could not fill the fields. userFound=" + (last?.userFound) +
        " passFound=" + (last?.passFound) +
        " inputs=" + (last?.inputCount ?? "?") +
        " url=" + (last?.url || "?") +
        (last?.error ? " err=" + last.error : "")
    });
  })().catch((err) => {
    try { sendResponse({ ok: false, error: String((err && err.message) || err) }); } catch {}
  });
  return true;
});
