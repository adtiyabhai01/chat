// Backup manual filler: can be used via console or message.
// (Main flow fills via background.js -> chrome.scripting.executeScript.)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type !== "FILL_CREDENTIALS") return;
  const { username, password, userSelector, passSelector } = msg;
  function setVal(el, v) {
    if (!el) return false;
    el.focus();
    try { el.value = ""; } catch {}
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, "value")
        || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value");
      const setter = desc && desc.set;
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
      if (setter && nativeSetter && setter !== nativeSetter) nativeSetter.call(el, v);
      else if (setter) setter.call(el, v);
      else el.value = v;
    } catch { el.value = v; }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  const u = document.querySelector(userSelector || 'input[name="username"]');
  const p = document.querySelector(passSelector || 'input[name="password"]');
  setVal(u, username);
  setVal(p, password);
});
