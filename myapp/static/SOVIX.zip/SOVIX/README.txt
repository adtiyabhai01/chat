SOVIX PortalLogin v0.3.0 - friendly setup (no commands needed)

1. Open chrome://extensions in Chrome -> turn Developer mode (top right) ON ->
   Load unpacked -> select the extension folder from this package.
2. Click the S logo in the toolbar (pin it from the puzzle menu) or press
   Ctrl+Shift+L on the keyboard -> the side panel will open. On first run the list will be empty +
   you will get an "Open demo portal form" button. To change the shortcut:
   remap the SOVIX key at chrome://extensions/shortcuts.
3. New portal: press + in the header (use Back at the top to go back) -> Portal Name +
   Website URL -> build steps with + Add step:
   - Input: Username -> username/email + XPath (empty = auto-detect,
     or press ⌖ (pick button) then click an element on the page to fetch its selector)
   - Input: Password -> password + XPath
   - Input: MFA Code -> MFA secret key (Base32), a live code preview is shown
   - Click: Button -> Login button
   - Wait -> pause (ms), Wait: URL change -> for multi-page logins, wait until
     the next page URL text appears (e.g. dashboard)
   -> Save Portal. After saving you return to the list + a "Saved" popup for 2 sec.
   On a row: eye icon = View, pencil icon = Edit, trash icon = Delete (with confirmation).
4. Click a portal row -> a new foreground tab opens and the fields are filled (green
   outline shown for 2.5 sec). The portal you opened moves to the top of the list
   (recent first). Favicon + domain subtitle are shown in the row.
5. Env keys: Portal Name "outlook" ->
   outlook_username, outlook_password, outlook_mfa (auto-save, auto-fill).
6. A confirmation appears before Delete so data is not lost by mistake.

Note: Custom portals stay in this laptop's chrome.storage only, do not share them with anyone.
Styles are shared: extension/styles.css (both popup + sidepanel).
